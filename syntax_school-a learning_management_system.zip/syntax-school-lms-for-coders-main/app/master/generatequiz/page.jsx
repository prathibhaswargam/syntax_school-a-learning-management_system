import { GenerateQuizComponent } from '@/components/generate-quiz'
import React from 'react'

const page = () => {
  return (
    <div>
        <GenerateQuizComponent />
    </div>
  )
}

export default page