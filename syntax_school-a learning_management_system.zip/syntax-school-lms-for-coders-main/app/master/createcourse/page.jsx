import { CourseCreationComponent } from '@/components/course-creation'
import React from 'react'

const page = () => {
  return (
    <div>
        <CourseCreationComponent />
    </div>
  )
}

export default page