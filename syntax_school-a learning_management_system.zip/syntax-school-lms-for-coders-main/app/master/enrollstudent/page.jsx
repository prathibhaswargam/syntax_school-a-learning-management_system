import { CourseEnrollmentComponent } from '@/components/course-enrollment'
import React from 'react'

const page = () => {
  return (
    <div>
        <CourseEnrollmentComponent />
    </div>
  )
}

export default page