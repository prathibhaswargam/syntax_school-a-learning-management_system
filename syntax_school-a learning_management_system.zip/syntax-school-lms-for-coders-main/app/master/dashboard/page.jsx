import { MasterDashboardComponent } from '@/components/master-dashboard'
import React from 'react'

const page = () => {
  return (
    <div>
        <MasterDashboardComponent />
    </div>
  )
}

export default page