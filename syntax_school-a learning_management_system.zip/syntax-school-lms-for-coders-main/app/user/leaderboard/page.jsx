import { StudentLeaderboardComponent } from '@/components/student-leaderboard'
import React from 'react'

const page = () => {
  return (
    <div>
        <StudentLeaderboardComponent />
    </div>
  )
}

export default page