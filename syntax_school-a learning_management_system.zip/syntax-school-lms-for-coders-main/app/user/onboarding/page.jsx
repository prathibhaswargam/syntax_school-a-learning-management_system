import { Onboarding } from '@/components/onboarding'
import React from 'react'

const page = () => {
  return (
    <div>
        <Onboarding />
    </div>
  )
}

export default page