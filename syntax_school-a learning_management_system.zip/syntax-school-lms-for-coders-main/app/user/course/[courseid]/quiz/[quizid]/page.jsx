import { QuizPageComponent } from '@/components/quiz-page'
import React from 'react'

const page = () => {
  return (
    <div>
        <QuizPageComponent />
    </div>
  )
}

export default page