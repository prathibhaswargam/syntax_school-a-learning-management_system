'use client'
import { CourseLessonsComponent } from '@/components/course-lessons'
import { useParams } from 'next/navigation'
import React from 'react'

const page = () => {
  


  return (
    <div>
        <CourseLessonsComponent />
    </div>
  )
}

export default page