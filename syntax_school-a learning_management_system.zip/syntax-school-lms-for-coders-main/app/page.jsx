import { LandingPageComponent } from "@/components/landing-page";
import Image from "next/image";

export default function Home() {

  return (
    
    <div>
    <LandingPageComponent />
    </div>
  );
}
