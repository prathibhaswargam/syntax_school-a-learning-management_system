console.log(selectedCourse)
